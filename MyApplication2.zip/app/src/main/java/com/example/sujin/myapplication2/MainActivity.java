package com.example.sujin.myapplication2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.Log;
import android.view.MotionEvent;
import java.util.Locale;

import static android.speech.tts.TextToSpeech.ERROR;

class DrawOB extends android.view.View{
    DrawOB(Context context){
        super(context);
    }
     int x1=100,y1=100,x2=300,y2=300;
     int a1=100,b1=400,a2=300,b2=500;
     int c1=490,d1=180,c2=450,d2=300,c3=550,d3=220,c4=430, d4=220, c5=530, d5=300;

     @Override
     public void onDraw(Canvas c){
        Path path = new Path();
        Paint pnt = new Paint();
        Log.v("드로우", "드로우발동!");
        //비 개발요소: 별 객체 인식하기
        //별 그리기
        path.moveTo(c1, d1);
	    path.lineTo(c1, d1);
	    path.lineTo(c2, d2);
	    path.lineTo(c3, d3);
	    path.lineTo(c4, d4);
	    path.lineTo(c5, d5);
	    path.lineTo(c1, d1);
        pnt.setStrokeWidth(3);
        pnt.setStyle(Paint.Style.FILL_AND_STROKE);
        pnt.setColor(Color.BLUE);
	    c.drawPath(path, pnt);

	    //사각형 그리기
	    Paint paint1 = new Paint();
        Paint paint2 = new Paint();
        paint1.setColor(Color.RED);
        paint2.setColor(Color.YELLOW);
        c.drawRect(x1, y1, x2, y2, paint1);
        c.drawRect(a1, b1, a2, b2, paint2);

    }

}
public class MainActivity extends AppCompatActivity {
   DrawOB mv1;
   DrawOB mv2;
   private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        mv1 = new DrawOB( this );
        mv2 = new DrawOB( this );
        setContentView( mv1);
        setContentView( mv2);

        tts = new TextToSpeech( this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != ERROR) {
                    // 언어를 선택한다.
                    tts.setLanguage( Locale.KOREAN );
                }
            }
        } );
    }
    protected void onDestroy() {
        super.onDestroy();
        // TTS 객체가 남아있다면 실행을 중지하고 메모리에서 제거한다.
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
    }
    //비개발 요소: onTouchEvent시, 2초마다 TALK [시간 제한 두기]
    public boolean onTouchEvent(MotionEvent event) {
        float x, y;
            x = event.getX();
            y = event.getY();

            /*  중요Point: 내 핸드폰의 경우 y의 default 값이 150이므로 -통해 default값 0으로 맞추어준다.*/
            y = y - 260;

            Log.v( "좌표값", x + "," + y ); //터치하는 곳의 좌표값을 로그 창에서 볼 수 있다.
         switch (event.getAction()) {
             case MotionEvent.ACTION_DOWN:
                    if (mv1.x1 < x && mv1.x2 > x && mv1.y1 < y && mv1.y2 > y) {
                        Log.v( "도형", "빨간 사각형" );
                        tts.setPitch( 1.0f );         // 음성 톤은 기본 설정
                        tts.speak( "빨간 사각형", TextToSpeech.QUEUE_FLUSH, null );
                    } else if (mv2.a1 < x && mv2.a2 > x && mv2.b1 < y && mv2.b2 > y) {
                        Log.v( "도형", "노란 사각형" );
                        tts.setPitch( 1.0f );         // 음성 톤은 기본 설정
                        tts.speak( "노란 사각형", TextToSpeech.QUEUE_FLUSH, null );
                    } else {
                        Log.v( "도형 없음", "Nothing" );
                        tts.setPitch( 1.0f );         // 음성 톤은 기본 설정
                        tts.speak( "도형 없음", TextToSpeech.QUEUE_FLUSH, null );
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    Log.v( "Hello", "Hell0" );
                        if (mv1.x1 < x && mv1.x2 > x && mv1.y1 < y && mv1.y2 > y) {
                            Log.v( "도형", "빨간 사각형" );
                            tts.setPitch( 1.0f );
                            tts.speak( "빨간 사각형", TextToSpeech.QUEUE_FLUSH, null );
                        } else if (mv2.a1 < x && mv2.a2 > x && mv2.b1 < y && mv2.b2 > y) {
                            Log.v( "도형", "노란 사각형" );
                            tts.setPitch( 1.0f );
                            tts.speak( "노란 사각형", TextToSpeech.QUEUE_FLUSH, null );
                        } else {
                            Log.v( "도형 없음", "Nothing" );
                            tts.setPitch( 1.0f );
                            tts.speak( "도형 없음", TextToSpeech.QUEUE_FLUSH, null );
                        }
                        break;
                        case MotionEvent.ACTION_UP:
                            Log.v( "Hello2", "Hello2" );
                            break;
            };
            return true;
    }
}