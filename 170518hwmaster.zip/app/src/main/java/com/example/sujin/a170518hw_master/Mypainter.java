package com.example.sujin.a170518hw_master;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
//이미지 위에 그림  그리기&지우기 및
//터치위치 좌표값 출력 class
public class Mypainter extends View {
     private float oldX;
    private float oldY;
    Bitmap mbitmap;
    Bitmap bm;
    Canvas mcanvas;
    Paint mpaint = new Paint();
    Paint mBitmapPaint = new Paint();
    private Path mPath;
    public ArrayList<Float> point_X = new ArrayList<Float>();

    public Mypainter(Context context, @Nullable AttributeSet attrs)
    {
        super(context, attrs);
        mpaint.setColor(Color.BLACK);
        mpaint.setStrokeWidth(5);
        mpaint.setStyle(Paint.Style.STROKE);
    }
    public Mypainter(Context context)
    {
        super(context);
        mpaint.setColor(Color.BLACK);
        mpaint.setStrokeWidth(5);
        mpaint.setStyle(Paint.Style.STROKE);
    }
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh)
    {
        super.onSizeChanged(w, h, oldw, oldh);

        bm = BitmapFactory.decodeResource(getResources(), // 배경 이미지 비트맵
                R.drawable.draw1);

        mbitmap = Bitmap.createBitmap(w,h, Bitmap.Config.ARGB_8888);
        mcanvas = new Canvas(mbitmap);
        mPath = new Path();
        mBitmapPaint = new Paint(Paint.DITHER_FLAG);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int width = canvas.getWidth();
        int height = canvas.getHeight();
        super.onDraw(canvas);
        if(mbitmap != null) {
            Bitmap resize_bitmap = Bitmap.createScaledBitmap(bm, width, height, true);
            canvas.drawBitmap( resize_bitmap, 0, 0, mBitmapPaint );
            canvas.drawPath( mPath, mpaint ); //해당 이미지 위에 그림을 그린다.
        }
    }
    public boolean onTouchEvent(MotionEvent event) {
        Float X = (Float)event.getX();
        Float Y = (Float)event.getY();
        switch (event.getAction()& MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                mPath.moveTo(X, Y);
                oldX = X;
                oldY = Y;
                point_X.add(oldX);
                point_X.add(oldY);
                mcanvas.drawPoint(oldX, oldY, mpaint);
                break;
            case MotionEvent.ACTION_MOVE:
                mPath.lineTo(oldX, oldY);
                oldX = X;
                oldY = Y;
                point_X.add(oldX);
                point_X.add(oldY);
                break;
            case MotionEvent.ACTION_UP:
                mPath.lineTo(oldX, oldY);
                break;
        }
        Log.v( "좌표값&x,y", String.valueOf( point_X ) );
        invalidate();
        return true;
    }
    public void penRed()
    {
        mpaint.setColor(Color.RED);
    }
    public void penBlue()
    {
        mpaint.setColor(Color.BLUE);
    }

    //(그림의 path) 지우기 기능
    public void Refresh()
    {
        mPath.reset();
        invalidate();
    }
}